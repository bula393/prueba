-- MySQL dump 10.13  Distrib 8.0.39, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: ASTRO_SPORT
-- ------------------------------------------------------
-- Server version	8.0.39-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `CLIENTES`
--

DROP TABLE IF EXISTS `CLIENTES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CLIENTES` (
  `DNI` int NOT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  `apellido` varchar(45) DEFAULT NULL,
  `direccion` varchar(45) DEFAULT NULL,
  `correo` varchar(45) DEFAULT NULL,
  `telefono` int DEFAULT NULL,
  `contraseña` varchar(45) DEFAULT NULL,
  `edad` int DEFAULT NULL,
  PRIMARY KEY (`DNI`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENTES`
--

LOCK TABLES `CLIENTES` WRITE;
/*!40000 ALTER TABLE `CLIENTES` DISABLE KEYS */;
INSERT INTO `CLIENTES` VALUES (48693121,'Matias','Faya','General Paz 12345','matifaya07@gmail.com',1191184,'cachi1930',16);
/*!40000 ALTER TABLE `CLIENTES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Empleado`
--

DROP TABLE IF EXISTS `Empleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Empleado` (
  `dni` int NOT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  `apellido` varchar(45) DEFAULT NULL,
  `direccion` varchar(45) DEFAULT NULL,
  `telefono` int DEFAULT NULL,
  `categoria` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`dni`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Empleado`
--

LOCK TABLES `Empleado` WRITE;
/*!40000 ALTER TABLE `Empleado` DISABLE KEYS */;
/*!40000 ALTER TABLE `Empleado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Estado`
--

DROP TABLE IF EXISTS `Estado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Estado` (
  `idEstado` int DEFAULT NULL,
  `descripcion` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Estado`
--

LOCK TABLES `Estado` WRITE;
/*!40000 ALTER TABLE `Estado` DISABLE KEYS */;
/*!40000 ALTER TABLE `Estado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categoria`
--

DROP TABLE IF EXISTS `categoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categoria` (
  `nombre` varchar(45) DEFAULT NULL,
  `id` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categoria`
--

LOCK TABLES `categoria` WRITE;
/*!40000 ALTER TABLE `categoria` DISABLE KEYS */;
INSERT INTO `categoria` VALUES ('botines',0),('guantes de arquero',1),('remeras',2),('kits de entrenamiento',3),('accesorios',4),('calzado',5);
/*!40000 ALTER TABLE `categoria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clientes` (
  `DNI` int NOT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  `apellido` varchar(45) DEFAULT NULL,
  `direccion` varchar(45) DEFAULT NULL,
  `correo` varchar(45) DEFAULT NULL,
  `telefono` int DEFAULT NULL,
  `contraseña` varchar(45) DEFAULT NULL,
  `edad` int DEFAULT NULL,
  PRIMARY KEY (`DNI`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `compra`
--

DROP TABLE IF EXISTS `compra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `compra` (
  `fecha` date DEFAULT NULL,
  `targetaDePago` varchar(45) DEFAULT NULL,
  `precioFinal` varchar(45) DEFAULT NULL,
  `Cliente_Dni` int DEFAULT NULL,
  `Producto_Codigo` int DEFAULT NULL,
  KEY `Cliente_Dni` (`Cliente_Dni`),
  CONSTRAINT `compra_ibfk_1` FOREIGN KEY (`Cliente_Dni`) REFERENCES `clientes` (`DNI`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compra`
--

LOCK TABLES `compra` WRITE;
/*!40000 ALTER TABLE `compra` DISABLE KEYS */;
/*!40000 ALTER TABLE `compra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empleado`
--

DROP TABLE IF EXISTS `empleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empleado` (
  `dni` int NOT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  `apellido` varchar(45) DEFAULT NULL,
  `direccion` varchar(45) DEFAULT NULL,
  `telefono` int DEFAULT NULL,
  `categoria` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`dni`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empleado`
--

LOCK TABLES `empleado` WRITE;
/*!40000 ALTER TABLE `empleado` DISABLE KEYS */;
/*!40000 ALTER TABLE `empleado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estado`
--

DROP TABLE IF EXISTS `estado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `estado` (
  `idEstado` int DEFAULT NULL,
  `descripcion` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estado`
--

LOCK TABLES `estado` WRITE;
/*!40000 ALTER TABLE `estado` DISABLE KEYS */;
/*!40000 ALTER TABLE `estado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `productos`
--

DROP TABLE IF EXISTS `productos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `productos` (
  `Codigo` int NOT NULL,
  `marca` varchar(45) DEFAULT NULL,
  `modelo` varchar(45) DEFAULT NULL,
  `precio` int DEFAULT NULL,
  `subcategoria_idsubcategoria` int NOT NULL,
  `foto` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Codigo`),
  KEY `fk_productos_subcategoria1_idx` (`subcategoria_idsubcategoria`),
  CONSTRAINT `fk_productos_subcategoria1` FOREIGN KEY (`subcategoria_idsubcategoria`) REFERENCES `subcategoria` (`idsubcategoria`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productos`
--

LOCK TABLES `productos` WRITE;
/*!40000 ALTER TABLE `productos` DISABLE KEYS */;
INSERT INTO `productos` VALUES (0,'nike','mercurial superfly',110,0,'/imagenes/BOTINES-tapones/BOTINES-tapones1.jpg'),(1,'puma','ultra ultimate',90,0,'/imagenes/BOTINES-tapones/BOTINES-tapones2.jpg'),(2,'puma','future 7',77,0,'/imagenes/BOTINES-tapones/BOTINES-tapones3.jpg'),(3,'puma','future ultimate',89,0,'/imagenes/BOTINES-tapones/BOTINES-tapones4.jpg'),(4,'nike','mercurial vapor 14 academy fg',70,0,'/imagenes/BOTINES-tapones/BOTINES-tapones5.jpg'),(5,'nike','mercurial vapor 14 academy mg',80,0,'/imagenes/BOTINES-tapones/BOTINES-tapones6.jpg'),(6,'adidas','predator',105,0,'/imagenes/BOTINES-tapones/BOTINES-tapones7.jpg'),(7,'adidas','X 18',95,0,'/imagenes/BOTINES-tapones/BOTINES-tapones8.jpg'),(9,'umbro','pro 5',80,1,'/imagenes/BOTINES-s-tapones/BotinDeFutsal1.webp'),(10,'kelme','indoor copa',75,1,'/imagenes/BOTINES-s-tapones/BotinDeFutsal2.jpg'),(11,'adidas','X crazy fast legue tf',95,1,'/imagenes/BOTINES-s-tapones/BotinDeFutsal3.webp'),(12,'nike','mercurial vapor 15 academy',120,1,'/imagenes/BOTINES-s-tapones/BotinDeFutsal4.webp'),(13,'puma','future match',75,1,'/imagenes/BOTINES-s-tapones/BotinDeFutsal5.png'),(14,'umbro','pro 6',85,1,'/imagenes/BOTINES-s-tapones/BotinDeFutsal6.jpg'),(15,'umbro','pro 5 bump dragon',90,1,'/imagenes/BOTINES-s-tapones/BotinDeFutsal7.webp'),(16,'nike','tiempo leyend 9',65,1,'/imagenes/BOTINES-s-tapones/BotinDeFutsal8.webp'),(17,'reusch','attrakt starter',40,2,'/imagenes/guantes/guantes1.jpg'),(18,'DRB','leader 22',55,2,'/imagenes/guantes/guantes2.jpg'),(19,'DRB','leader 22 pro',35,2,'/imagenes/guantes/guantes3.png'),(20,'DRB','master 22',60,2,'/imagenes/guantes/guantes4.jpg'),(21,'DRB','feline 22',55,2,'/imagenes/guantes/guantes5.png'),(22,'reusch','attrakt infinity',40,2,'/imagenes/guantes/guantes6.jpg'),(23,'reusch','pure contact',60,2,'/imagenes/guantes/guantes7.jpg'),(24,'VGFC','turnen',55,2,'/imagenes/guantes/guantes8.jpg'),(25,'puma','ultra grip',35,3,'/imagenes/guantes/guantes9.jpg'),(26,'VGFC','bursa',70,3,'/imagenes/guantes/guantesflat1.jpg'),(27,'VGFC','roth',50,3,'/imagenes/guantes/guantesflat2.jpg'),(28,'shinestone','kalesi',30,3,'/imagenes/guantes/guantesflat3.webp'),(29,'reusch','attakt fusion',40,3,'/imagenes/guantes/guantesflat4.webp'),(30,'ho','protek blade',40,3,'/imagenes/guantes/guantesflat5.jpg'),(31,'ho','arena',20,3,'/imagenes/guantes/guantesflat6.jpg'),(32,'ho','axilal',20,3,'/imagenes/guantes/guantesflat7.jpg'),(33,'amago','los pumas',25,4,'/imagenes/musculasas/remeraM1.jpg'),(34,'imago','dry lite',25,4,'/imagenes/musculasas/remeraM2.jpg'),(35,'imago','tawhiri',23,4,'/imagenes/musculasas/remeraM3.jpg'),(36,'adidas','boca',30,4,'/imagenes/musculasas/remeraM5.webp'),(37,'adidas','river',30,4,'/imagenes/musculasas/remeraM6.jpg'),(38,'puma','indeoendiente',20,4,'/imagenes/musculasas/remeraM7.jpeg'),(39,'kappa','racing',18,4,'/imagenes/musculasas/remeraM8.jpg'),(40,'nike','barcelona',35,4,'/imagenes/musculasas/remerasM11.jpg'),(41,'imago','microfibra',18,5,'/imagenes/remeras-depor/remera1.jpg'),(42,'puma','manchater city',50,5,'/imagenes/remeras-depor/remera3.jpg'),(43,'underarmor','tela fit',18,5,'/imagenes/remeras-depor/remera4.jpg'),(44,'aidas','argentina',30,5,'/imagenes/remeras-depor/remera5.jpg'),(45,'reebok','atletic dept',22,5,'/imagenes/remeras-depor/remera6.jpg'),(46,NULL,'roja',12,5,'/imagenes/remeras-depor/remera2.jpg'),(47,'adidas','real madrid',50,5,'/imagenes/remeras-depor/remera9.jpg'),(48,'sg','local',20,5,'/imagenes/remeras-depor/remera7.jpg'),(49,NULL,'Escaleras',5,6,'/imagenes/KitsDeEntrenamiento/Escaleras.webp'),(50,NULL,'Barra',25,6,'/imagenes/KitsDeEntrenamiento/BarraEntrenamiento.jpg'),(51,NULL,'Discos',10,6,'/imagenes/KitsDeEntrenamiento/DiscosDeLasPesas.jpg'),(52,NULL,'Pesa Rusa',40,6,'/imagenes/KitsDeEntrenamiento/kettlebell.jpg'),(53,NULL,'Rueda Abdominales',12,6,'/imagenes/KitsDeEntrenamiento/ruedaabs.jpg'),(54,NULL,'Caja',105,6,'/imagenes/KitsDeEntrenamiento/cajon.jpg'),(55,NULL,'Pelota Con Peso',55,6,'/imagenes/KitsDeEntrenamiento/pelotaconpeso.jpg'),(56,NULL,'Colchonetas',20,6,'/imagenes/KitsDeEntrenamiento/Colchonetas.jpg'),(57,NULL,'Pesas',120,7,'/imagenes/KitsDeEntrenamiento/setmancuernas.jpg'),(58,NULL,'Bandas Elasticas',30,7,'/imagenes/KitsDeEntrenamiento/bandaselasticas.jpg'),(59,NULL,'Soga con Agarre',14,7,'/imagenes/KitsDeEntrenamiento/conmanija.jpg'),(60,NULL,'Banco Plano',100,7,'/imagenes/KitsDeEntrenamiento/banco.jpg'),(61,NULL,'Barra',15,7,'/imagenes/KitsDeEntrenamiento/barra.jpg'),(62,NULL,'Pera Box',10,7,'/imagenes/KitsDeEntrenamiento/pera.jpg'),(63,NULL,'Guantes Boxeo',45,7,'/imagenes/KitsDeEntrenamiento/guantesbox.jpg'),(64,NULL,'Tobilleras Peso',2,7,'/imagenes/KitsDeEntrenamiento/tobillera-con-peso.jpg'),(65,NULL,'Muñequeras',5,7,'/imagenes/KitsDeEntrenamiento/muñequerasdearena.jpg'),(66,NULL,'Pelota De Basquet',15,8,'/imagenes/Accesorios/basquet.jpg'),(67,'Adidas','Pelota De Futbol 11',80,8,'/imagenes/Accesorios/Pelota11.avif'),(68,'Givova','Pelota De Futsal',62,8,'/imagenes/Accesorios/givova.jpeg'),(69,'Penn','Pelota De Tennis',3,8,'/imagenes/Accesorios/pelotatenis.jpg'),(70,NULL,'Pelota De Golf',16,8,'/imagenes/Accesorios/golf.jpg'),(71,'Penalty','Pelota De Handball',50,8,'/imagenes/Accesorios/handball.jpg'),(72,NULL,'Pelota De Ping Pong',1,8,'/imagenes/Accesorios/pelotapingpong.jpg'),(73,'Sorma','Pelota De Volley',45,8,'/imagenes/Accesorios/volley.jpg'),(74,'Gilbert','Pelota De Rugby',15,8,'/imagenes/Accesorios/ovalada.webp'),(75,NULL,'Soga',5,9,'/imagenes/Accesorios/soga.jpg'),(76,'Presslove','Straps',13,9,'/imagenes/Accesorios/straps.jpg'),(77,'Nassau','Palo De Hockey',13,9,'/imagenes/Accesorios/palodehockey.jpg'),(78,'Wilson','Raqueta De Tenis',365,9,'/imagenes/Accesorios/raquetatenis.jpg'),(79,'Head Speed','Raqueta De Padel',400,9,'/imagenes/Accesorios/raquetapadel.jpg'),(80,'Callaway','Palo De Golf',285,9,'/imagenes/Accesorios/palodegolf.jpg'),(81,NULL,'Badminton Racket',475,9,'/imagenes/Accesorios/badminton.jpg'),(82,'Kipsta BA100','Guante De Beisbol',120,9,'/imagenes/Accesorios/guantebeisbol.avif'),(83,'HAT HITTER','Palo De Beisbol',5,9,'/imagenes/Accesorios/palobeisbol.webp'),(84,'Under Armor','Zapatilla Runner Negra',123,10,'/imagenes/Calzado/ZapatillasPaCorrer.avif'),(85,'Under Armor','Zapatilla Runner',110,10,'/imagenes/Calzado/ZapatillasPaCorrer2.avif'),(86,'Nike','Medias Runner',30,10,'/imagenes/Calzado/MediasCorrer.avif'),(87,'Fox Socks','Medias Antideslizantes',15,10,'/imagenes/Calzado/MediasAntideslizantes.jpg'),(88,'Fox Socks','Medias Antideslizantes B&W',15,10,'/imagenes/Calzado/MediasAntideslizantes2.avif'),(89,'Proyec','Vendas Box',13,10,'/imagenes/Calzado/vendasBox.jpg'),(90,'Nike','Guantes Gym',45,10,'/imagenes/Calzado/guantes.jpeg'),(91,'Wilson','Calza Corta',25,10,'/imagenes/Calzado/Calza.png'),(92,'Body Care','Calza Larga',45,10,'/imagenes/Calzado/CalzaLarga.jpg');
/*!40000 ALTER TABLE `productos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subcategoria`
--

DROP TABLE IF EXISTS `subcategoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subcategoria` (
  `idsubcategoria` int NOT NULL,
  `categoria_id` int NOT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idsubcategoria`),
  KEY `fk_subcategoria_categoria1_idx` (`categoria_id`),
  CONSTRAINT `fk_subcategoria_categoria1` FOREIGN KEY (`categoria_id`) REFERENCES `categoria` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subcategoria`
--

LOCK TABLES `subcategoria` WRITE;
/*!40000 ALTER TABLE `subcategoria` DISABLE KEYS */;
INSERT INTO `subcategoria` VALUES (0,0,'botines con tapones'),(1,0,'botines sin tapones'),(2,1,'Corte Negativo'),(3,1,'Corte Flat'),(4,2,'muscualosas'),(5,2,'deportivas'),(6,3,'campo'),(7,3,'gym'),(8,4,'Pelotas'),(9,4,'Instrumentos'),(10,5,'deportivo');
/*!40000 ALTER TABLE `subcategoria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tallas`
--

DROP TABLE IF EXISTS `tallas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tallas` (
  `id_talla` int NOT NULL AUTO_INCREMENT,
  `id_categoria` int NOT NULL,
  `nombre_talla` varchar(50) NOT NULL,
  PRIMARY KEY (`id_talla`),
  KEY `id_categoria` (`id_categoria`),
  CONSTRAINT `tallas_ibfk_1` FOREIGN KEY (`id_categoria`) REFERENCES `categoria` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tallas`
--

LOCK TABLES `tallas` WRITE;
/*!40000 ALTER TABLE `tallas` DISABLE KEYS */;
INSERT INTO `tallas` VALUES (31,0,'35'),(32,0,'36'),(33,0,'37'),(34,0,'38'),(35,0,'39'),(36,0,'40'),(37,1,'S'),(38,1,'M'),(39,1,'L'),(40,1,'XL'),(41,1,'XXL'),(42,1,'XXXL'),(43,2,'S'),(44,2,'M'),(45,2,'L'),(46,2,'XL'),(47,2,'XXL'),(48,2,'XXXL'),(49,5,'36'),(50,5,'37'),(51,5,'38'),(52,5,'39'),(53,5,'40'),(54,5,'41');
/*!40000 ALTER TABLE `tallas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-29  9:20:58
