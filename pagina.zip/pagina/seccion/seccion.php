<?php
$servername = "127.0.0.1";
    $database = "ASTRO_SPORT";
    $username = "alumno";
    $password = "alumnoipm";
    
    $conexion = mysqli_connect($servername, $username, $password, $database); // se crea la conexion


    if (!$conexion) {
        die("Conexion fallida: " . mysqli_connect_error());
    }
    else{
        $consultas = "select  * from productos where subcategoria_idsubcategoria in (select idsubcategoria from subcategoria where categoria_id=(select id from categoria where nombre='".$_GET['categoria']."')) and subcategoria_idsubcategoria%2=0;";
        $resultados=mysqli_query($conexion, $consultas);
        $consulta = "select  * from productos where subcategoria_idsubcategoria in (select idsubcategoria from subcategoria where categoria_id=(select id from categoria where nombre='".$_GET['categoria']."')) and subcategoria_idsubcategoria%2!=0;";
        $resultado=mysqli_query($conexion, $consulta);
        $sub="select nombre from subcategoria where categoria_id=(select id from categoria where nombre='".$_GET['categoria']."') and idsubcategoria%2=0;";
        $subs="select nombre from subcategoria where categoria_id=(select id from categoria where nombre='".$_GET['categoria']."') and idsubcategoria%2!=0;";
        $resultadol=mysqli_query($conexion, $sub);
        $resultadot=mysqli_query($conexion, $subs);
    }

    mysqli_close($conexion);
?>


<html>
  <head>
    <meta charset="utf-8" />
    <meta content="width=de vice-width, initial-scale=1" name="viewport" />
    <title>ASTRO SPORT</title>
    <link rel="stylesheet" href="seccion.css" />
  </head>
  <body>
    <header>
      <a href="\principal\principal.php"><img id=logo src="\imagenes\logo-blanco.png"/></a>
      <img id=nombre src="\imagenes\NOMBRELOGO.png"/>
      <button id="esquina">
        <a href="\formulario\iniciosesion.php"><h1>INICIO SESION</h1></a>
    </button>  
    </header> 
    <h1 class="subseccion">
      <?php
          echo $_GET['categoria'];
      ?>
    </h1> seccion
    <ul class="nav">    
    <li>
      <a href=""><img id=opciones src="\imagenes\opciones.png"></a>
      <ul class="desplegable">
        <h1>Equipamiento</h1>

              <li><a class="desplegable" href="\seccion\seccion.php?categoria=botines"><h3>Botines</h3></a></li>
              <li><a class="desplegable" href="\seccion\seccion.php?categoria=guantes de arquero"><h3>Guantes de arquero</h3></a></li>
              <li><a class="desplegable" href="\seccion\seccion.php?categoria=remeras"><h3>Remeras de entrenamiento</h3></a></li>
              <li><a class="desplegable" href="\seccion\seccion.php?categoria=Kits entre"><h3>Kits de entrenamiento</h3></a></li>
 
              <h1>Indumentaria</h1>
 
              <li><a class="desplegable" href="\seccion\seccion.html"><h3>Accesorios</h3></a></li>
              <li><a class="desplegable" href="\seccion\seccion.html"><h3>Calzado</h3></a> </li>
         
  </ul>
      </li>
    </ul>
    <?php
    while($fila=mysqli_fetch_assoc($resultadol)){ ?>
      <h1 class="subseccion">
        <?php echo $fila['nombre'] ?> 
      </h1> 
    <?php
    }
    ?>
  <div class="desplazable">
    <?php
    while($fila=mysqli_fetch_assoc($resultados)){ ?>
    <a href="/productos/producto.php?codigo=<?php echo $fila['Codigo'] ?> "><img class="item" src="<?php echo $fila['foto'] ?> "/></a>
<?php
    }
  ?>
  </div>
  <?php
    while($fila=mysqli_fetch_assoc($resultadot)){ ?>
      <h1 class="subseccion">
        <?php echo $fila['nombre'] ?> 
      </h1> 
    <?php
    }
    ?>
  <div class="desplazable">
  <?php
    while($fila=mysqli_fetch_assoc($resultado)){ ?>
    <a href="/productos/producto.php?codigo=<?php echo $fila['Codigo'] ?> "><img class="item" src="<?php echo $fila['foto'] ?> "/></a>
<?php
    }
  ?>
  </div>
  </body>
</html>

