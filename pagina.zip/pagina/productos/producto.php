<?php
$servername = "127.0.0.1";
$database = "ASTRO_SPORT";
$username = "alumno";
$password = "alumnoipm";
    
    $conexion = mysqli_connect($servername, $username, $password, $database); // se crea la conexion


    if (!$conexion) {
        die("Conexion fallida: " . mysqli_connect_error());
    }
    else{
        $query = "select  * from productos where Codigo=".$_GET['codigo']."";
        $consultas= mysqli_query($conexion,$query );
        $fila=mysqli_fetch_assoc($consultas);
    }

    mysqli_close($conexion);
?>
<html>
  <head>
    <meta charset="utf-8" />
    <meta content="width=de vice-width, initial-scale=1" name="viewport" />
    <title>ASTRO SPORT</title>
    <link rel="icon" type="icon" href="/imagenes/logo-negro.png">
    <link rel="stylesheet" href="productos.css" />
  </head>
  <body>
    <header>
      <a href="\principal\principal.php"><img id=logo src="\imagenes\logo-blanco.png"/></a>
      <img id=nombre src="\imagenes\NOMBRELOGO.png"/>
      <button>
        <a href="\formulario\iniciosesion.php"><h1>INICIO SESION</h1></a>
      </button>  
    </header>     
    <div id="conjunto">
      <ul class="nav">    
        <li>
          <ul class="desplegable">
            <h1>Equipamiento</h1>

            <li><a class="desplegable" href="\seccion\seccion.php?categoria=botines"><h3>Botines</h3></a></li>
              <li><a class="desplegable" href="\seccion\seccion.php?categoria=guantes de arquero"><h3>Guantes de arquero</h3></a></li>
              <li><a class="desplegable" href="\seccion\seccion.php?categoria=remeras"><h3>Remeras de entrenamiento</h3></a></li>
              <li><a class="desplegable" href="\seccion\seccion.php?categoria=Kits entre"><h3>Kits de entrenamiento</h3></a></li>
 
              <h1>Indumentaria</h1>
 
              <li><a class="desplegable" href="\seccion\seccion.html"><h3>Accesorios</h3></a></li>
              <li><a class="desplegable" href="\seccion\seccion.html"><h3>Calzado</h3></a> </li>
            </ul>
          </li>
        </ul>
 
    
    <img id="central" src="<?php echo $fila['foto'] ?>" alt="">
      <div class="especificaciones">

      <h1>
        <?php echo $fila['marca'] ?> 
      </h1> 

      <h1 >
        <?php echo $fila['modelo'] ?> 
      </h1> 

        <h2 id="talle">talle</h2>
        <form action="producto.php">
          <select name="talle" required>
            <option value="0">s</option>
            <option value="1">4</option>
            <option value="2">3</option>
            <option value="3">2</option>
          </select>
          <input type="text" class="input" placeholder="CANTIDAD" required name="cantidad" />
          <input type="submit" class="input" required value="AÑADIR AL CARRITO" />
        </form>
        <?php
    while($fila=mysqli_fetch_assoc($consultas)){ ?>
      <h2 >
        precio:<?php echo $fila['precio'] ?> 
      </h2> 
    <?php
    } 
    ?>
      </div>
    </div>    
  </body>
</html>

