-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 01-11-2024 a las 03:29:09
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `astro_sport`
--
CREATE DATABASE IF NOT EXISTS `astro_sport` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `astro_sport`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categoria`
--

CREATE TABLE `categoria` (
  `nombre` varchar(45) DEFAULT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `categoria`
--

INSERT INTO `categoria` (`nombre`, `id`) VALUES
('botines', 0),
('guantes de arquero', 1),
('remeras', 2),
('kits de entrenamiento', 3),
('accesorios', 4),
('calzado', 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `DNI` int(11) NOT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  `apellido` varchar(45) DEFAULT NULL,
  `direccion` varchar(45) DEFAULT NULL,
  `correo` varchar(45) DEFAULT NULL,
  `telefono` int(11) DEFAULT NULL,
  `contraseña` varchar(45) DEFAULT NULL,
  `edad` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`DNI`, `nombre`, `apellido`, `direccion`, `correo`, `telefono`, `contraseña`, `edad`) VALUES
(43525325, 'sdadasda', 'fafa', 'dsafas', 'santi.buhler1@gmail.com', 231, '12345678', 16);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `compra`
--

CREATE TABLE `compra` (
  `fecha` date DEFAULT NULL,
  `targetaDePago` varchar(45) DEFAULT NULL,
  `precioFinal` varchar(45) DEFAULT NULL,
  `Cliente_Dni` int(11) DEFAULT NULL,
  `Producto_Codigo` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleado`
--

CREATE TABLE `empleado` (
  `dni` int(11) NOT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  `apellido` varchar(45) DEFAULT NULL,
  `direccion` varchar(45) DEFAULT NULL,
  `telefono` int(11) DEFAULT NULL,
  `categoria` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado`
--

CREATE TABLE `estado` (
  `idEstado` int(11) DEFAULT NULL,
  `descripcion` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `Codigo` int(11) NOT NULL,
  `marca` varchar(45) DEFAULT NULL,
  `modelo` varchar(45) DEFAULT NULL,
  `precio` int(11) DEFAULT NULL,
  `subcategoria_idsubcategoria` int(11) NOT NULL,
  `foto` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`Codigo`, `marca`, `modelo`, `precio`, `subcategoria_idsubcategoria`, `foto`) VALUES
(0, 'nike', 'mercurial superfly', 110, 0, '/imagenes/BOTINES-tapones/BOTINES-tapones1.jpg'),
(1, 'puma', 'ultra ultimate', 90, 0, '/imagenes/BOTINES-tapones/BOTINES-tapones2.jpg'),
(2, 'puma', 'future 7', 77, 0, '/imagenes/BOTINES-tapones/BOTINES-tapones3.jpg'),
(3, 'puma', 'future ultimate', 89, 0, '/imagenes/BOTINES-tapones/BOTINES-tapones4.jpg'),
(4, 'nike', 'mercurial vapor 14 academy fg', 70, 0, '/imagenes/BOTINES-tapones/BOTINES-tapones5.jpg'),
(5, 'nike', 'mercurial vapor 14 academy mg', 80, 0, '/imagenes/BOTINES-tapones/BOTINES-tapones6.jpg'),
(6, 'adidas', 'predator', 105, 0, '/imagenes/BOTINES-tapones/BOTINES-tapones7.jpg'),
(7, 'adidas', 'X 18', 95, 0, '/imagenes/BOTINES-tapones/BOTINES-tapones8.jpg'),
(9, 'umbro', 'pro 5', 80, 1, '/imagenes/BOTINES-s-tapones/BotinDeFutsal1.webp'),
(10, 'kelme', 'indoor copa', 75, 1, '/imagenes/BOTINES-s-tapones/BotinDeFutsal2.jpg'),
(11, 'adidas', 'X crazy fast legue tf', 95, 1, '/imagenes/BOTINES-s-tapones/BotinDeFutsal3.webp'),
(12, 'nike', 'mercurial vapor 15 academy', 120, 1, '/imagenes/BOTINES-s-tapones/BotinDeFutsal4.webp'),
(13, 'puma', 'future match', 75, 1, '/imagenes/BOTINES-s-tapones/BotinDeFutsal5.png'),
(14, 'umbro', 'pro 6', 85, 1, '/imagenes/BOTINES-s-tapones/BotinDeFutsal6.jpg'),
(15, 'umbro', 'pro 5 bump dragon', 90, 1, '/imagenes/BOTINES-s-tapones/BotinDeFutsal7.webp'),
(16, 'nike', 'tiempo leyend 9', 65, 1, '/imagenes/BOTINES-s-tapones/BotinDeFutsal8.webp'),
(17, 'reusch', 'attrakt starter', 40, 2, '/imagenes/guantes/guantes1.jpg'),
(18, 'DRB', 'leader 22', 55, 2, '/imagenes/guantes/guantes2.jpg'),
(19, 'DRB', 'leader 22 pro', 35, 2, '/imagenes/guantes/guantes3.png'),
(20, 'DRB', 'master 22', 60, 2, '/imagenes/guantes/guantes4.jpg'),
(21, 'DRB', 'feline 22', 55, 2, '/imagenes/guantes/guantes5.png'),
(22, 'reusch', 'attrakt infinity', 40, 2, '/imagenes/guantes/guantes6.jpg'),
(23, 'reusch', 'pure contact', 60, 2, '/imagenes/guantes/guantes7.jpg'),
(24, 'VGFC', 'turnen', 55, 2, '/imagenes/guantes/guantes8.jpg'),
(25, 'puma', 'ultra grip', 35, 3, '/imagenes/guantes/guantes9.jpg'),
(26, 'VGFC', 'bursa', 70, 3, '/imagenes/guantes/guantesflat1.jpg'),
(27, 'VGFC', 'roth', 50, 3, '/imagenes/guantes/guantesflat2.jpg'),
(28, 'shinestone', 'kalesi', 30, 3, '/imagenes/guantes/guantesflat3.webp'),
(29, 'reusch', 'attakt fusion', 40, 3, '/imagenes/guantes/guantesflat4.webp'),
(30, 'ho', 'protek blade', 40, 3, '/imagenes/guantes/guantesflat5.jpg'),
(31, 'ho', 'arena', 20, 3, '/imagenes/guantes/guantesflat6.jpg'),
(32, 'ho', 'axilal', 20, 3, '/imagenes/guantes/guantesflat7.jpg'),
(33, 'amago', 'los pumas', 25, 4, '/imagenes/musculasas/remeraM1.jpg'),
(34, 'imago', 'dry lite', 25, 4, '/imagenes/musculasas/remeraM2.jpg'),
(35, 'imago', 'tawhiri', 23, 4, '/imagenes/musculasas/remeraM3.jpg'),
(36, 'adidas', 'boca', 30, 4, '/imagenes/musculasas/remeraM5.webp'),
(37, 'adidas', 'river', 30, 4, '/imagenes/musculasas/remeraM6.jpg'),
(38, 'puma', 'indeoendiente', 20, 4, '/imagenes/musculasas/remeraM7.jpeg'),
(39, 'kappa', 'racing', 18, 4, '/imagenes/musculasas/remeraM8.jpg'),
(40, 'nike', 'barcelona', 35, 4, '/imagenes/musculasas/remerasM11.jpg'),
(41, 'imago', 'microfibra', 18, 5, '/imagenes/remeras-depor/remera1.jpg'),
(42, 'puma', 'manchater city', 50, 5, '/imagenes/remeras-depor/remera3.jpg'),
(43, 'underarmor', 'tela fit', 18, 5, '/imagenes/remeras-depor/remera4.jpg'),
(44, 'aidas', 'argentina', 30, 5, '/imagenes/remeras-depor/remera5.jpg'),
(45, 'reebok', 'atletic dept', 22, 5, '/imagenes/remeras-depor/remera6.jpg'),
(46, NULL, 'roja', 12, 5, '/imagenes/remeras-depor/remera2.jpg'),
(47, 'adidas', 'real madrid', 50, 5, '/imagenes/remeras-depor/remera9.jpg'),
(48, 'sg', 'local', 20, 5, '/imagenes/remeras-depor/remera7.jpg'),
(49, NULL, 'Escaleras', 5, 6, '/imagenes/KitsDeEntrenamiento/Escaleras.webp'),
(50, NULL, 'Barra', 25, 6, '/imagenes/KitsDeEntrenamiento/BarraEntrenamiento.jpg'),
(51, NULL, 'Discos', 10, 6, '/imagenes/KitsDeEntrenamiento/DiscosDeLasPesas.jpg'),
(52, NULL, 'Pesa Rusa', 40, 6, '/imagenes/KitsDeEntrenamiento/kettlebell.jpg'),
(53, NULL, 'Rueda Abdominales', 12, 6, '/imagenes/KitsDeEntrenamiento/ruedaabs.jpg'),
(54, NULL, 'Caja', 105, 6, '/imagenes/KitsDeEntrenamiento/cajon.jpg'),
(55, NULL, 'Pelota Con Peso', 55, 6, '/imagenes/KitsDeEntrenamiento/pelotaconpeso.jpg'),
(56, NULL, 'Colchonetas', 20, 6, '/imagenes/KitsDeEntrenamiento/Colchonetas.jpg'),
(57, NULL, 'Pesas', 120, 7, '/imagenes/KitsDeEntrenamiento/setmancuernas.jpg'),
(58, NULL, 'Bandas Elasticas', 30, 7, '/imagenes/KitsDeEntrenamiento/bandaselasticas.jpg'),
(59, NULL, 'Soga con Agarre', 14, 7, '/imagenes/KitsDeEntrenamiento/conmanija.jpg'),
(60, NULL, 'Banco Plano', 100, 7, '/imagenes/KitsDeEntrenamiento/banco.jpg'),
(61, NULL, 'Barra', 15, 7, '/imagenes/KitsDeEntrenamiento/barra.jpg'),
(62, NULL, 'Pera Box', 10, 7, '/imagenes/KitsDeEntrenamiento/pera.jpg'),
(63, NULL, 'Guantes Boxeo', 45, 7, '/imagenes/KitsDeEntrenamiento/guantesbox.jpg'),
(64, NULL, 'Tobilleras Peso', 2, 7, '/imagenes/KitsDeEntrenamiento/tobillera-con-peso.jpg'),
(65, NULL, 'Muñequeras', 5, 7, '/imagenes/KitsDeEntrenamiento/muñequerasdearena.jpg'),
(66, NULL, 'Pelota De Basquet', 15, 8, '/imagenes/Accesorios/basquet.jpg'),
(67, 'Adidas', 'Pelota De Futbol 11', 80, 8, '/imagenes/Accesorios/Pelota11.avif'),
(68, 'Givova', 'Pelota De Futsal', 62, 8, '/imagenes/Accesorios/givova.jpeg'),
(69, 'Penn', 'Pelota De Tennis', 3, 8, '/imagenes/Accesorios/pelotatenis.jpg'),
(70, NULL, 'Pelota De Golf', 16, 8, '/imagenes/Accesorios/golf.jpg'),
(71, 'Penalty', 'Pelota De Handball', 50, 8, '/imagenes/Accesorios/handball.jpg'),
(72, NULL, 'Pelota De Ping Pong', 1, 8, '/imagenes/Accesorios/pelotapingpong.jpg'),
(73, 'Sorma', 'Pelota De Volley', 45, 8, '/imagenes/Accesorios/volley.jpg'),
(74, 'Gilbert', 'Pelota De Rugby', 15, 8, '/imagenes/Accesorios/ovalada.webp'),
(75, NULL, 'Soga', 5, 9, '/imagenes/Accesorios/soga.jpg'),
(76, 'Presslove', 'Straps', 13, 9, '/imagenes/Accesorios/straps.jpg'),
(77, 'Nassau', 'Palo De Hockey', 13, 9, '/imagenes/Accesorios/palodehockey.jpg'),
(78, 'Wilson', 'Raqueta De Tenis', 365, 9, '/imagenes/Accesorios/raquetatenis.jpg'),
(79, 'Head Speed', 'Raqueta De Padel', 400, 9, '/imagenes/Accesorios/raquetapadel.jpg'),
(80, 'Callaway', 'Palo De Golf', 285, 9, '/imagenes/Accesorios/palodegolf.jpg'),
(81, NULL, 'Badminton Racket', 475, 9, '/imagenes/Accesorios/badminton.jpg'),
(82, 'Kipsta BA100', 'Guante De Beisbol', 120, 9, '/imagenes/Accesorios/guantebeisbol.avif'),
(83, 'HAT HITTER', 'Palo De Beisbol', 5, 9, '/imagenes/Accesorios/palobeisbol.webp'),
(84, 'Under Armor', 'Zapatilla Runner Negra', 123, 10, '/imagenes/Calzado/ZapatillasPaCorrer.avif'),
(85, 'Under Armor', 'Zapatilla Runner', 110, 10, '/imagenes/Calzado/ZapatillasPaCorrer2.avif'),
(86, 'Nike', 'Medias Runner', 30, 10, '/imagenes/Calzado/MediasCorrer.avif'),
(87, 'Fox Socks', 'Medias Antideslizantes', 15, 10, '/imagenes/Calzado/MediasAntideslizantes.jpg'),
(88, 'Fox Socks', 'Medias Antideslizantes B&W', 15, 10, '/imagenes/Calzado/MediasAntideslizantes2.avif'),
(89, 'Proyec', 'Vendas Box', 13, 10, '/imagenes/Calzado/vendasBox.jpg'),
(90, 'Nike', 'Guantes Gym', 45, 10, '/imagenes/Calzado/guantes.jpeg'),
(91, 'Wilson', 'Calza Corta', 25, 10, '/imagenes/Calzado/Calza.png'),
(92, 'Body Care', 'Calza Larga', 45, 10, '/imagenes/Calzado/CalzaLarga.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `subcategoria`
--

CREATE TABLE `subcategoria` (
  `idsubcategoria` int(11) NOT NULL,
  `categoria_id` int(11) NOT NULL,
  `nombre` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `subcategoria`
--

INSERT INTO `subcategoria` (`idsubcategoria`, `categoria_id`, `nombre`) VALUES
(0, 0, 'botines con tapones'),
(1, 0, 'botines sin tapones'),
(2, 1, 'Corte Negativo'),
(3, 1, 'Corte Flat'),
(4, 2, 'muscualosas'),
(5, 2, 'deportivas'),
(6, 3, 'campo'),
(7, 3, 'gym'),
(8, 4, 'Pelotas'),
(9, 4, 'Instrumentos'),
(10, 5, 'deportivo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tallas`
--

CREATE TABLE `tallas` (
  `id_talla` int(11) NOT NULL,
  `id_categoria` int(11) NOT NULL,
  `nombre_talla` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tallas`
--

INSERT INTO `tallas` (`id_talla`, `id_categoria`, `nombre_talla`) VALUES
(31, 0, '35'),
(32, 0, '36'),
(33, 0, '37'),
(34, 0, '38'),
(35, 0, '39'),
(36, 0, '40'),
(37, 1, 'S'),
(38, 1, 'M'),
(39, 1, 'L'),
(40, 1, 'XL'),
(41, 1, 'XXL'),
(42, 1, 'XXXL'),
(43, 2, 'S'),
(44, 2, 'M'),
(45, 2, 'L'),
(46, 2, 'XL'),
(47, 2, 'XXL'),
(48, 2, 'XXXL'),
(49, 5, '36'),
(50, 5, '37'),
(51, 5, '38'),
(52, 5, '39'),
(53, 5, '40'),
(54, 5, '41');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categoria`
--
ALTER TABLE `categoria`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`DNI`);

--
-- Indices de la tabla `compra`
--
ALTER TABLE `compra`
  ADD KEY `Cliente_Dni` (`Cliente_Dni`);

--
-- Indices de la tabla `empleado`
--
ALTER TABLE `empleado`
  ADD PRIMARY KEY (`dni`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`Codigo`),
  ADD KEY `fk_productos_subcategoria1_idx` (`subcategoria_idsubcategoria`);

--
-- Indices de la tabla `subcategoria`
--
ALTER TABLE `subcategoria`
  ADD PRIMARY KEY (`idsubcategoria`),
  ADD KEY `fk_subcategoria_categoria1_idx` (`categoria_id`);

--
-- Indices de la tabla `tallas`
--
ALTER TABLE `tallas`
  ADD PRIMARY KEY (`id_talla`),
  ADD KEY `id_categoria` (`id_categoria`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `tallas`
--
ALTER TABLE `tallas`
  MODIFY `id_talla` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `compra`
--
ALTER TABLE `compra`
  ADD CONSTRAINT `compra_ibfk_1` FOREIGN KEY (`Cliente_Dni`) REFERENCES `clientes` (`DNI`);

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `fk_productos_subcategoria1` FOREIGN KEY (`subcategoria_idsubcategoria`) REFERENCES `subcategoria` (`idsubcategoria`);

--
-- Filtros para la tabla `subcategoria`
--
ALTER TABLE `subcategoria`
  ADD CONSTRAINT `fk_subcategoria_categoria1` FOREIGN KEY (`categoria_id`) REFERENCES `categoria` (`id`);

--
-- Filtros para la tabla `tallas`
--
ALTER TABLE `tallas`
  ADD CONSTRAINT `tallas_ibfk_1` FOREIGN KEY (`id_categoria`) REFERENCES `categoria` (`id`);
--
-- Base de datos: `phpmyadmin`
--
CREATE DATABASE IF NOT EXISTS `phpmyadmin` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
USE `phpmyadmin`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__bookmark`
--

CREATE TABLE `pma__bookmark` (
  `id` int(10) UNSIGNED NOT NULL,
  `dbase` varchar(255) NOT NULL DEFAULT '',
  `user` varchar(255) NOT NULL DEFAULT '',
  `label` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `query` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Bookmarks';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__central_columns`
--

CREATE TABLE `pma__central_columns` (
  `db_name` varchar(64) NOT NULL,
  `col_name` varchar(64) NOT NULL,
  `col_type` varchar(64) NOT NULL,
  `col_length` text DEFAULT NULL,
  `col_collation` varchar(64) NOT NULL,
  `col_isNull` tinyint(1) NOT NULL,
  `col_extra` varchar(255) DEFAULT '',
  `col_default` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Central list of columns';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__column_info`
--

CREATE TABLE `pma__column_info` (
  `id` int(5) UNSIGNED NOT NULL,
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `column_name` varchar(64) NOT NULL DEFAULT '',
  `comment` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `mimetype` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `transformation` varchar(255) NOT NULL DEFAULT '',
  `transformation_options` varchar(255) NOT NULL DEFAULT '',
  `input_transformation` varchar(255) NOT NULL DEFAULT '',
  `input_transformation_options` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Column information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__designer_settings`
--

CREATE TABLE `pma__designer_settings` (
  `username` varchar(64) NOT NULL,
  `settings_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Settings related to Designer';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__export_templates`
--

CREATE TABLE `pma__export_templates` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) NOT NULL,
  `export_type` varchar(10) NOT NULL,
  `template_name` varchar(64) NOT NULL,
  `template_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved export templates';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__favorite`
--

CREATE TABLE `pma__favorite` (
  `username` varchar(64) NOT NULL,
  `tables` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Favorite tables';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__history`
--

CREATE TABLE `pma__history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(64) NOT NULL DEFAULT '',
  `db` varchar(64) NOT NULL DEFAULT '',
  `table` varchar(64) NOT NULL DEFAULT '',
  `timevalue` timestamp NOT NULL DEFAULT current_timestamp(),
  `sqlquery` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='SQL history for phpMyAdmin';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__navigationhiding`
--

CREATE TABLE `pma__navigationhiding` (
  `username` varchar(64) NOT NULL,
  `item_name` varchar(64) NOT NULL,
  `item_type` varchar(64) NOT NULL,
  `db_name` varchar(64) NOT NULL,
  `table_name` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Hidden items of navigation tree';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__pdf_pages`
--

CREATE TABLE `pma__pdf_pages` (
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `page_nr` int(10) UNSIGNED NOT NULL,
  `page_descr` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='PDF relation pages for phpMyAdmin';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__recent`
--

CREATE TABLE `pma__recent` (
  `username` varchar(64) NOT NULL,
  `tables` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Recently accessed tables';

--
-- Volcado de datos para la tabla `pma__recent`
--

INSERT INTO `pma__recent` (`username`, `tables`) VALUES
('root', '[{\"db\":\"astro_sport\",\"table\":\"compra\"},{\"db\":\"astro_sport\",\"table\":\"clientes\"}]');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__relation`
--

CREATE TABLE `pma__relation` (
  `master_db` varchar(64) NOT NULL DEFAULT '',
  `master_table` varchar(64) NOT NULL DEFAULT '',
  `master_field` varchar(64) NOT NULL DEFAULT '',
  `foreign_db` varchar(64) NOT NULL DEFAULT '',
  `foreign_table` varchar(64) NOT NULL DEFAULT '',
  `foreign_field` varchar(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Relation table';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__savedsearches`
--

CREATE TABLE `pma__savedsearches` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) NOT NULL DEFAULT '',
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `search_name` varchar(64) NOT NULL DEFAULT '',
  `search_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved searches';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__table_coords`
--

CREATE TABLE `pma__table_coords` (
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `pdf_page_number` int(11) NOT NULL DEFAULT 0,
  `x` float UNSIGNED NOT NULL DEFAULT 0,
  `y` float UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table coordinates for phpMyAdmin PDF output';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__table_info`
--

CREATE TABLE `pma__table_info` (
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `display_field` varchar(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__table_uiprefs`
--

CREATE TABLE `pma__table_uiprefs` (
  `username` varchar(64) NOT NULL,
  `db_name` varchar(64) NOT NULL,
  `table_name` varchar(64) NOT NULL,
  `prefs` text NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Tables'' UI preferences';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__tracking`
--

CREATE TABLE `pma__tracking` (
  `db_name` varchar(64) NOT NULL,
  `table_name` varchar(64) NOT NULL,
  `version` int(10) UNSIGNED NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `schema_snapshot` text NOT NULL,
  `schema_sql` text DEFAULT NULL,
  `data_sql` longtext DEFAULT NULL,
  `tracking` set('UPDATE','REPLACE','INSERT','DELETE','TRUNCATE','CREATE DATABASE','ALTER DATABASE','DROP DATABASE','CREATE TABLE','ALTER TABLE','RENAME TABLE','DROP TABLE','CREATE INDEX','DROP INDEX','CREATE VIEW','ALTER VIEW','DROP VIEW') DEFAULT NULL,
  `tracking_active` int(1) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Database changes tracking for phpMyAdmin';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__userconfig`
--

CREATE TABLE `pma__userconfig` (
  `username` varchar(64) NOT NULL,
  `timevalue` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `config_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User preferences storage for phpMyAdmin';

--
-- Volcado de datos para la tabla `pma__userconfig`
--

INSERT INTO `pma__userconfig` (`username`, `timevalue`, `config_data`) VALUES
('root', '2024-11-01 02:28:34', '{\"Console\\/Mode\":\"collapse\",\"lang\":\"es\"}');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__usergroups`
--

CREATE TABLE `pma__usergroups` (
  `usergroup` varchar(64) NOT NULL,
  `tab` varchar(64) NOT NULL,
  `allowed` enum('Y','N') NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User groups with configured menu items';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__users`
--

CREATE TABLE `pma__users` (
  `username` varchar(64) NOT NULL,
  `usergroup` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Users and their assignments to user groups';

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `pma__central_columns`
--
ALTER TABLE `pma__central_columns`
  ADD PRIMARY KEY (`db_name`,`col_name`);

--
-- Indices de la tabla `pma__column_info`
--
ALTER TABLE `pma__column_info`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `db_name` (`db_name`,`table_name`,`column_name`);

--
-- Indices de la tabla `pma__designer_settings`
--
ALTER TABLE `pma__designer_settings`
  ADD PRIMARY KEY (`username`);

--
-- Indices de la tabla `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_user_type_template` (`username`,`export_type`,`template_name`);

--
-- Indices de la tabla `pma__favorite`
--
ALTER TABLE `pma__favorite`
  ADD PRIMARY KEY (`username`);

--
-- Indices de la tabla `pma__history`
--
ALTER TABLE `pma__history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`,`db`,`table`,`timevalue`);

--
-- Indices de la tabla `pma__navigationhiding`
--
ALTER TABLE `pma__navigationhiding`
  ADD PRIMARY KEY (`username`,`item_name`,`item_type`,`db_name`,`table_name`);

--
-- Indices de la tabla `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  ADD PRIMARY KEY (`page_nr`),
  ADD KEY `db_name` (`db_name`);

--
-- Indices de la tabla `pma__recent`
--
ALTER TABLE `pma__recent`
  ADD PRIMARY KEY (`username`);

--
-- Indices de la tabla `pma__relation`
--
ALTER TABLE `pma__relation`
  ADD PRIMARY KEY (`master_db`,`master_table`,`master_field`),
  ADD KEY `foreign_field` (`foreign_db`,`foreign_table`);

--
-- Indices de la tabla `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_savedsearches_username_dbname` (`username`,`db_name`,`search_name`);

--
-- Indices de la tabla `pma__table_coords`
--
ALTER TABLE `pma__table_coords`
  ADD PRIMARY KEY (`db_name`,`table_name`,`pdf_page_number`);

--
-- Indices de la tabla `pma__table_info`
--
ALTER TABLE `pma__table_info`
  ADD PRIMARY KEY (`db_name`,`table_name`);

--
-- Indices de la tabla `pma__table_uiprefs`
--
ALTER TABLE `pma__table_uiprefs`
  ADD PRIMARY KEY (`username`,`db_name`,`table_name`);

--
-- Indices de la tabla `pma__tracking`
--
ALTER TABLE `pma__tracking`
  ADD PRIMARY KEY (`db_name`,`table_name`,`version`);

--
-- Indices de la tabla `pma__userconfig`
--
ALTER TABLE `pma__userconfig`
  ADD PRIMARY KEY (`username`);

--
-- Indices de la tabla `pma__usergroups`
--
ALTER TABLE `pma__usergroups`
  ADD PRIMARY KEY (`usergroup`,`tab`,`allowed`);

--
-- Indices de la tabla `pma__users`
--
ALTER TABLE `pma__users`
  ADD PRIMARY KEY (`username`,`usergroup`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `pma__column_info`
--
ALTER TABLE `pma__column_info`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `pma__history`
--
ALTER TABLE `pma__history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  MODIFY `page_nr` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- Base de datos: `test`
--
CREATE DATABASE IF NOT EXISTS `test` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `test`;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
